import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CurdService } from '../../services/curd.service';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MessageComponent } from '../../shared-components/message/message.component';
import { DISABLED, FormControl } from '@angular/forms/src/model';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registrationForm: FormGroup;
  submitted = false;
  editMode = false;
  constructor(
    public dialog: MatDialog,
    private formbuilder: FormBuilder,
    private router: Router,
    private curdService: CurdService,
    private route: ActivatedRoute
  ) {

    let routeData = this.route.snapshot.params["name"];
    if (routeData != null)
      this.editMode = true;
  }

  ngOnInit() {
    let routeData = this.route.snapshot.params["name"];

    this.registrationForm = this.formbuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });



    if (routeData != null) {
      this.editMode = true;
      this.curdService.searchByUser(routeData)
        .subscribe(result => {
          console.log(result);
          //this.registrationForm.controls.firstName.disable();
          this.registrationForm.setValue(result);
        });
    }
  }

  get formFields() { return this.registrationForm.controls; }
  registerUser() {
    this.submitted = true;

    if (this.registrationForm.invalid) {
      return;
    }
    if (this.editMode) {
      this.curdService.editUser(this.registrationForm.value)
        .subscribe(result => {
          if (result == true) {
            const dialogRef = this.dialog.open(MessageComponent, {
              width: '350px',
              data: { title: 'Registration', content: 'Your details updated successfully' }
            });

            dialogRef.afterClosed().subscribe(result => {
              this.router.navigate(['/userDetail']);
            });
          }
          else {
            const dialogRef = this.dialog.open(MessageComponent, {
              width: '350px',
              data: { title: 'Registration', content: 'Your Details not found' }
            });

            dialogRef.afterClosed().subscribe(result => {
            });
          }
        });
    }
    else
      this.curdService.createNewUser(this.registrationForm.value)
        .subscribe(result => {
          if (result == true) {
            const dialogRef = this.dialog.open(MessageComponent, {
              width: '350px',
              data: { title: 'Registration', content: 'You have registered successfully' }
            });

            dialogRef.afterClosed().subscribe(result => {
              this.router.navigate(['/userDetail']);
            });
          }
          else {
            const dialogRef = this.dialog.open(MessageComponent, {
              width: '350px',
              data: { title: 'Registration', content: 'You have provided details are already exist' }
            });

            dialogRef.afterClosed().subscribe(result => {
            });
          }
        });
  }

}
