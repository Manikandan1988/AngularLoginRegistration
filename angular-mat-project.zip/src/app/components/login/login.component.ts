import { Component, OnInit, NgModule, EventEmitter, Output } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MessageComponent } from '../../shared-components/message/message.component';
import { MessageModel } from '../../shared-components/models/message-model';
import { Router, ActivatedRoute } from '@angular/router';
import { CurdService } from '../../services/curd.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  message: MessageModel;
  model: any = {};

  constructor(private curdService: CurdService, public dialog: MatDialog, private router: Router) {
    this.message = new MessageModel();
    this.curdService.isUserLoggedIn.next(localStorage.getItem("LoginUser") != null);
  }

  ngOnInit() {

  }


  login() {

    // let allUsers = JSON.parse(localStorage.getItem("allUsers"));
    // allUsers = allUsers == null ? [] : allUsers;
    // let loggeduser = allUsers.filter(row => {
    //   return row.firstName == this.model.userName && row.password == this.model.password
    // });
    this.curdService.loginUser(this.model.userName, this.model.password)
      .subscribe(result => {

        if (result == true) {

          const dialogRef = this.dialog.open(MessageComponent, {
            width: '350px',
            data: { title: 'Login', content: 'You have successfully Login' }
          });


          dialogRef.afterClosed().subscribe(result => {
            localStorage.setItem("LoginUser", this.model.userName);
            this.router.navigate(['/userDetail']);
          });

        }
        else {
          const dialogRef = this.dialog.open(MessageComponent, {
            width: '350px',
            data: { title: 'Login', content: 'Login Failed' }
          });


          dialogRef.afterClosed().subscribe(result => {

          });
        }

      });

  }
}
