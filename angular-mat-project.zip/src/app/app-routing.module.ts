import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from '../app/components/login/login.component';
import { RegistrationComponent } from '../app/components/registration/registration.component';
import { UserDetailsComponent } from '../app/components/user-details/user-details.component';
import { AuthService } from './services/auth.service';
const routes: Routes = [
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'newUser', component: RegistrationComponent
  },
  {
    path: 'editUser/:name', component: RegistrationComponent
  },
  {
    path: 'userDetail', component: UserDetailsComponent, canActivate: [AuthService]
  },
  {
    path: '', redirectTo: '/userDetail', pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
