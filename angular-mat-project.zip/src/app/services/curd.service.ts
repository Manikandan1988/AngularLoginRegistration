import { Injectable } from '@angular/core';
import { Observable, Subject, observable } from 'rxjs';
import { mapTo, map, subscribeOn, observeOn } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CurdService {

  public isUserLoggedIn = new Subject<boolean>();

  constructor(private http: HttpClient) {


  }
  userDetails: Array<any> = JSON.parse(localStorage.getItem("allUsers")) || [];
  retriveAllUsers(): Observable<Array<any>> {

    return Observable.create(observer => {
      observer.next(this.userDetails);
      observer.complete();
    });
  }

  isLoggedIn() {
    return localStorage.getItem("LoginUser") != null;
  }

  searchByUser(userName): Observable<any> {
    return Observable.create(observer => {
      let result = this.userDetails.filter(row => { return row.firstName == userName });
      observer.next(result[0] || {});
      observer.complete();
    });
  }

  createNewUser(user): Observable<boolean> {
    return Observable.create(observer => {

      let result = this.userDetails.filter(row => { return row.firstName == user.firstName });
      if (result.length > 0)
        observer.next(false);
      else {
        this.userDetails.push(user);
        localStorage.setItem('allUsers', JSON.stringify(this.userDetails));
        observer.next(true);
      }
    });
  }

  editUser(user): Observable<boolean> {
    return Observable.create(observer => {

      let result = this.userDetails.filter(row => { return row.firstName == user.firstName });
      if (result.length > 0) {
        let index = this.userDetails.findIndex(row => row.firstName == user.firstName);
        this.userDetails[index] = user;
        localStorage.setItem('allUsers', JSON.stringify(this.userDetails));
        observer.next(true);
      }
      else {
        observer.next(false);
      }
      observer.complete();
    });
  }

  deleteUser(user): Observable<boolean> {
    return Observable.create(observer => {

      let result = this.userDetails.filter(row => { return row.firstName == user.firstName });
      if (result.length > 0 && localStorage.getItem('LoginUser') != user.firstName) {
        let index = this.userDetails.findIndex(row => row.firstName == user.firstName);
        this.userDetails.splice(index, 1);
        localStorage.setItem('allUsers', JSON.stringify(this.userDetails));
        observer.next(true);
      }
      else
        observer.next(false);

    });
  }
  loginUser(userName, password): Observable<boolean> {
    return Observable.create(observer => {

      let isvalidUser = this.userDetails.filter(row => { return row.firstName == userName && row.password == password });
      observer.next(isvalidUser.length > 0);
      observer.complete();
    });
  }

  logOut(): Observable<boolean> {
    return Observable.create(observer => {
      localStorage.removeItem("LoginUser");
      observer.next(true);
      observer.complete();
    });
  }

}
