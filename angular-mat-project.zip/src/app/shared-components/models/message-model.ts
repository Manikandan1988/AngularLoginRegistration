export class MessageModel {
    constructor()
    {}
    public title: string;
    public isSuccessMessage: boolean;
    public isErrorMessage: boolean;
    public isWarningMessage: boolean;
    public content: string;

}
