import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MessageModel } from '../models/message-model';
@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {

  title: string;
  content: string;
  constructor(
    public dialogRef: MatDialogRef<MessageComponent>, @Inject(MAT_DIALOG_DATA) data
  ) {

    this.title = data.title;
    this.content = data.content;

  }

  noButtonClick() {
    this.dialogRef.close();
  }

  ngOnInit() {

  }

}
