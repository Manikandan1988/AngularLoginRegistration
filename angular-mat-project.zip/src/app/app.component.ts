import { Component, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { CurdService } from './services/curd.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-mat-project';
  public loggedUser: string;
  public isLogIn = false;
  constructor(private router: Router, private curdService: CurdService) {
    this.loggedUser = localStorage.getItem("LoginUser");
    this.curdService.isUserLoggedIn.subscribe(result => {
      this.isUserLoggedIn(result);
    }
    );
  }

  logout() {

    this.curdService.logOut()
      .subscribe(result => {
        if (result == true) {
          this.loggedUser = "";
          this.isLogIn = false;
          this.router.navigate(['/login']);
        }
      });
  }

  isUserLoggedIn(value: boolean) {
    this.loggedUser = "";
    if (value == true) {
      this.isLogIn = value;
      this.loggedUser = localStorage.getItem("LoginUser");
    }
  }


}
