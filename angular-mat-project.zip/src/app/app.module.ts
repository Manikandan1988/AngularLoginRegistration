import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MessageComponent } from './shared-components/message/message.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule, MatFormFieldModule, MatIconModule, MatButtonModule, MatInputModule, MatSelectModule, MatRadioModule, MatCheckboxModule } from '@angular/material';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { UserDetailsComponent } from './components/user-details/user-details.component';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CurdService } from '../app/services/curd.service';
// used to create fake backend
import { fakeBackendProvider } from '../app/services/FakeBackendInterceptor';


@NgModule({
  declarations: [
    AppComponent,
    MessageComponent,
    LoginComponent,
    RegistrationComponent,
    UserDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatDialogModule,
    MatButtonModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCheckboxModule,
    MatIconModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
  entryComponents: [MessageComponent],
  exports: [],
  providers: [CurdService, fakeBackendProvider],
  bootstrap: [AppComponent]
})
export class AppModule { }
